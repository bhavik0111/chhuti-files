<footer class="footersection">
         <div class="container">
            <div class="ftnavsubsec">
               <div class="row">
                  <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                     <div class="ftaboutsec">
                        <a class="ftabimg" href="index.html"><img src="images/footer-logo.png" alt="" /></a>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard</p>
                     </div>
                  </div>
                  <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
                     <div class="quicklink ft-com-list">
                        <h4>Quick Links</h4>
                        <ul>
                           <li><a href="esim.html">New eSIM</a></li>
                           <li><a href="topup.html">Topup</a></li>
                           <li><a href="check-usage.html">Check Usage</a></li>
                           <li><a href="blog.html">Blog</a></li>
                           <li><a href="faq.html">Help & FAQs</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
                     <div class="ft-getintouch ft-com-list">
                        <h4>Get In Touch</h4>
                        <ul>
                           <li>
                              <i class="fa fa-map-marker"></i> Lorance 154, Town <br>
                              5248 MT, Worldwide
                           </li>
                           <li>
                              <a href="tel:1234562505"><i class="fa fa-phone"></i> (+1) 123-456-2505</a>
                           </li>
                           <li>
                              <a href="mailto:info@linkesim.com"><i class="fa fa-envelope"></i> info@linkesim.com</a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="400">
                     <div class="keepintouch">
                        <h4>Keep In Touch</h4>
                        <ul>
                           <li><a href=""><i class="fa fa-facebook"></i></a></li>
                           <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                           <li><a href=""><i class="fa fa-instagram"></i></a></li>
                        </ul>
                        <div class="stripe-logo"><img src="images/stripe-logo.png" alt=""></div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="copyrightsec">
               &copy;2023 LINKeSims | <a href="">Privacy legacy</a>
            </div>
         </div>
      </footer>