@extends('user.cart.layout.master')
@section('content')
<div class="innerpage-banner">
   <div class="container">
      <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
         <h3>Profile</h3>
      </div>
   </div>
</div>
   <div class="faq-page content comm-PTB">
      <div class="container-fluid">
         <div class="row">
            <div class="col-md-2 bg-dark">

               @include('user.profile.sidebar')
               
            </div>
            <!-- <div class="col-md-10">
               <div class="faq-listing" data-aos="fade-up" data-aos-delay="200">
                  <div class="accordion" id="accordionExample">
                     <h4>About eSIM and Eligible Devices</h4>
                     <div class="accordion-item">
                        <h2 class="accordion-header" id="acc-1">
                           <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#col-1" aria-expanded="true" aria-controls="col-1">
                           Is my smartphone eSIM capable?
                           </button>
                        </h2>
                        <div id="col-1" class="accordion-collapse collapse show" aria-labelledby="acc-1"
                           data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-item">
                        <h2 class="accordion-header" id="acc-2">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col-2" aria-expanded="false" aria-controls="col-2">
                           What is eSIM?
                           </button>
                        </h2>
                        <div id="col-2" class="accordion-collapse collapse" aria-labelledby="acc-2" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              <p>Bagages en cabine :</p>
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                              <p>Bagages en soute :</p>
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it t
                              </p>
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled 
                              </p>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-item">
                        <h2 class="accordion-header" id="acc-3">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col-3" aria-expanded="false" aria-controls="col-3">
                           Do I get a phone number with the eSIM?
                           </button>
                        </h2>
                        <div id="col-3" class="accordion-collapse collapse" aria-labelledby="acc-3" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever  Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-item">
                        <h2 class="accordion-header" id="acc-4">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col-4" aria-expanded="false" aria-controls="col-4">
                           I already have an eSIM in my phone. Can I add another?
                           </button>
                        </h2>
                        <div id="col-4" class="accordion-collapse collapse" aria-labelledby="acc-4" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                              </p>
                           </div>
                        </div>
                     </div>
                     <h4>Purchasing and setting up the eSIM</h4>
                     <div class="accordion-item">
                        <h2 class="accordion-header" id="acc-5">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col-5"  aria-expanded="false" aria-controls="col-5">
                           What happens when I buy? 
                           </button>
                        </h2>
                        <div id="col-5" class="accordion-collapse collapse" aria-labelledby="acc-5" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                              <p>Typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, </p>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-item">
                        <h2 class="accordion-header" id="acc-6">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col-6" aria-expanded="false" aria-controls="col-6">
                           How do I download and setup the eSIM?
                           </button>
                        </h2>
                        <div id="col-6" class="accordion-collapse collapse" aria-labelledby="acc-6" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                           </div>
                        </div>
                     </div>
                     <h4>Using the eSIM</h4>
                     <div class="accordion-item">
                        <h2 class="accordion-header" id="acc-7">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col-7" aria-expanded="false" aria-controls="col-7">
                           Can I use the same eSIM package in multiple countries?
                           </button>
                        </h2>
                        <div id="col-7" class="accordion-collapse collapse" aria-labelledby="acc-7" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing.
                              </p>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-item">
                        <h2 class="accordion-header" id="acc-8">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col-8"  aria-expanded="false" aria-controls="col-8">
                           How do I track my data usage?
                           </button>
                        </h2>
                        <div id="col-8" class="accordion-collapse collapse" aria-labelledby="acc-8" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-item">
                        <h2 class="accordion-header" id="acc-9">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col-9" aria-expanded="false" aria-controls="col-9">
                           I finished my data and need more; can I top up? 
                           </button>
                        </h2>
                        <div id="col-9" class="accordion-collapse collapse" aria-labelledby="acc-9" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              <p>
                                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-item">
                        <h2 class="accordion-header" id="acc-10">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col-10"  aria-expanded="false" aria-controls="col-10">
                           Can I transfer the eSIM to another device?
                           </button>
                        </h2>
                        <div id="col-10" class="accordion-collapse collapse" aria-labelledby="acc-10" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              <p>
                                 Typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                              <p>
                                 Eelectronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
             </div> -->
            <div class="col-md-10"> 
               <h6>welcome   {{auth()->user()->name}}</h6>
            </div>
             
         </div>
         
      </div>
   </div>
@endsection