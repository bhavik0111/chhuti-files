@extends('user.cart.layout.master')
                                                <!-- Checkout page -->
@section('content')

    <div class="innerpage-banner">
         <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
               <h3>Order Checkout</h3>
            </div>
         </div>
    </div>
    <div class="innerpage-common comm-PTB">
        <main class="form-signin">
            <div class="card">
                <form method="POST" action="{{ route('user.order.store') }}" enctype="multipart/form-data">
                    @csrf
                    <div class="card-body">
                        <!-- <h4 class="card-title">{{ __('Order') }}</h4> -->

                        <div class="form-group column" style="float:right">
                            <a href="{{ route('user.cart.index') }}" class="btn btn-dark"><b>Back</b></a>
                        </div>

                        <div class="form-group row">
                            <label for="first_name"
                                class="col-sm-3 text-end control-label col-form-label"><b>{{ __('First Name') }}</b></label>
                            <div class="col-sm-9">
                                <input id="first_name" type="text" class="form-control @error('first_name') is-invalid @enderror"
                                    name="first_name" value="{{ old('first_name') }}" required autocomplete="first_name" autofocus>
                            </div>
                            @error('first_name')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>

                        <div class="form-group row">
                            <label for="last_name"
                                class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Last Name') }}</b></label>
                            <div class="col-sm-9">
                                <input id="last_name" type="text" class="form-control @error('last_name') is-invalid @enderror"
                                    name="last_name" value="{{ old('last_name') }}" required autocomplete="last_name" autofocus>
                            </div>
                            @error('last_name')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>


                        <div class="form-group row">
                            <label for="phone"
                                class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Phone') }}</b></label>

                            <div class="col-sm-9">
                                <input id="phone" type="number" class="form-control @error('phone') is-invalid @enderror"
                                    name="phone" value="{{ old('phone') }}" required autocomplete="phone">

                            </div>
                            @error('phone')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>


                        <div class="form-group row">
                            <label for="email"
                                class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Email') }}</b></label>

                            <div class="col-sm-9">
                                <input type="email" id="email" class="form-control @error('email') is-invalid @enderror"
                                    name="email" value="{{ old('email') }}" required autocomplete="email">

                            </div>
                            @error('email')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>

                        <div class="form-group row">
                            <label for="shipping_address"
                                class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Shipping Address') }}</b></label>

                            <div class="col-sm-9">
                                <input id="shipping_address" type="text" class="form-control @error('shipping_address') is-invalid @enderror"
                                    name="shipping_address" value="{{ old('shipping_address') }}" required autocomplete="shipping_address">

                            </div>
                            @error('shipping_address')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>

                        <div class="form-group row">
                            <label for="order_date"
                                class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Order Date') }}</b></label>

                            <div class="col-sm-9">
                                <input type="date" id="order_date" class="form-control @error('order_date') is-invalid @enderror summernote"
                                name="order_date" value="{{ old('order_date') }}" required autocomplete="order_date">

                            </div>
                            @error('order_date')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group row">
                            <label for="order_date"
                                class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Products') }}</b></label>

                            <div class="col-sm-9">
                                @php $total = 0; @endphp
                                @foreach ($carts as $cart)
                                    @php $total = $total+$cart->product->price; @endphp
                                <div class="col-sm-3">{{ $cart->product->name }}  *  {{ $cart->qty }}</div>
                                @endforeach
                                <input type="hidden" value="{{ $total  }}" name="total"> 
                            </div>
                            @error('order_date')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Order Status') }}</b></label>
                            <div class="col-md-9">

                            
                                <div class="form-check">
                                    <input type="radio" class="form-check-input" id="customControlValidation1" name="order_status"value="2" required />

                                    <label class="form-check-label mb-0"
                                        for="customControlValidation1">{{ __('Progress') }}</label>
                                </div>
                                <div class="form-check">

                                    <input type="radio" class="form-check-input" id="customControlValidation2" name="order_status"
                                        value="1" required />
                                    <label class="form-check-label mb-0"
                                        for="customControlValidation2">{{ __('Complete') }}</label>
                                </div>
                                <div class="form-check">

                                    <input type="radio" class="form-check-input" id="customControlValidation2" name="order_status"
                                        value="0" required />
                                    <label class="form-check-label mb-0"
                                        for="customControlValidation2">{{ __('Cancel') }}</label>
                                </div>
                            </div>
                        </div>

                        

                        <div class="border-top">
                            <div class="card-body" style="float:center">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('submit') }}
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </main>
    </div>
@endsection
@push('scripts')
<script>

     $(document).ready(function() {
          $('.summernote').summernote();
        });



function addrow()
    {
        var html =
        '<div class="prod_feature">'+
            '<div class="form-group row">' +
                '<label for="title"  class="col-sm-3 text-end control-label col-form-label">{{ __('Title') }}' +
                '</label>' +

                '<div class="col-sm-8">'+
                    '<input type="text" name="title[]" class="form-control title"  id="title" required>' +
                '</div>' +
                '<div class="col-sm-1">'+
                    '<button type="button" class="btn btn-danger deleteRow">Delete</button>'+
                '</div>' +
            '</div>' +

            '<div class="form-group row">'+
                '<label for="add_description" class="col-sm-3 text-end control-label col-form-label">{{ __('Description') }}'+
                '</label>' +

                '<div class="col-sm-8">' +
                    '<textarea class="form-control summernote" name="add_description[]" id="add_description">{{ old('add_description') }}</textarea>' +
                '</div>' +
            '</div>'+
        '</div>';

        $('.features').append(html);

        $('.summernote').summernote();
    }

    $(document).on('click','.deleteRow',function (e) {
        e.preventDefault();
        $(this).closest('.prod_feature').remove();
    })

</script>
@endpush

