@extends('user.cart.layout.master')

<link rel="stylesheet" type="text/css" href="{{ asset('public/admin/assets/extra-libs/multicheck/multicheck.css') }}" />
<link rel="stylesheet" href="{{ asset('public/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css') }}" />

@section('content')

    <div class="innerpage-banner">
         <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
               <h3>Cart</h3>
            </div>
         </div>
    </div>
    <div class="innerpage-common comm-PTB">

        <!-- (FOR MSG) -->
        @if (session()->has('msg'))
            <div class="alert alert-success">
                {{ session()->get('msg') }}
            </div>
        @endif
        @if (session()->has('error_msg'))
            <div class="alert alert-danger">
                {{ session()->get('error_msg') }}
            </div>
        @endif
        <!-- (END MSG) -->
        <div class="card mb-3">
            <div class="card-body">
                <!-- <div class="card-header row">
                        <h4 class="card-title mb-3"><b>cart</b></h4>
                    </div> -->

                <div class="form-group column" style="float:right">
                    <a href="{{ route('user.home') }}" class="btn btn-dark"><b>Back</b></a>
                </div>

                <div class="table-responsive">
                    <table id="zero_config" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th><b>ID</b></th>
                                <th><b>product name</b></th> <!-- product_id as product name -->
                                <th><b>qty</b></th>
                                <th><b>Price</b></th>

                                <th><b>Action</b></th>
                            </tr>
                        </thead>
                        <tbody>
                            @php $total = 0; @endphp
                            @foreach ($cart_products as $key => $product)
                                @php

                                $total = $total+$product->price;
                                @endphp
                                {{-- <tr>
                                    <td><strong>{{ $cart->id }}</strong></td>
                                    <td>{{ $cart->product->name }}</td>

                                    <td>
                                        <input type="number" value="{{ $cart->qty }}" class="form-control"
                                            style="display:none;" id="qty_{{ $key }}"
                                            onfocusout="saveqty('{{ $key }}',this.value)">
                                            <input type="hidden" value="{{ $cart->product_id }}" id="product_id_{{ $key }}">
                                        <div id="display_qty_{{ $key }}">{{ $cart->qty }}</div>
                                    </td>
                                    <td>{{ $cart->product->price }}</td>

                                    <td>
                                        <!-- <a onclick="changeqty('{{ $key }}')"
                                            class="btn btn-info"><b>{{ __('Edit') }}</b></a> -->
                                            <a class="btn btn-info"><b>{{ __('Edit') }}</b></a>

                                        <form action="#" method="POST"
                                            onsubmit="return confirm('Are you sure Delete User?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit"
                                                class="btn btn-danger text-white"><b>{{ __('Delete') }}</b></button>
                                        </form>
                                    </td>
                                </tr> --}}
                                {{-- USsing session --}}
                                <tr>
                                    <td>{{ $key+1 }}</td>
                                    <td>{{ $product->name }}</td>
                                    <td>
                                    <input type="number" value="{{ $carts[$key]['qty'] }}" class="form-control"
                                            style="display:none;" id="qty_{{ $key }}"
                                            onfocusout="saveqty('{{ $key }}',this.value)">
                                            <input type="hidden" value="{{ $product->id }}" id="product_id_{{ $key }}">
                                        <div id="display_qty_{{ $key }}">{{ $carts[$key]['qty'] }}</div>
                                        </td>
                                        <td>{{ $product->price }}</td>
                                    <td>
                                        <a onclick="changeqty('{{ $key }}');"
                                            class="btn btn-info"><b>{{ __('Edit') }}</b></a>
                                            {{-- <a class="btn btn-info"><b>{{ __('Edit') }}</b></a> --}}

                                        <form action="#" method="POST"
                                            onsubmit="return confirm('Are you sure Delete User?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit"
                                                class="btn btn-danger text-white"><b>{{ __('Delete') }}</b></button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                            <tr>
                                <td colspan="3" align="right"><b>Total:</b></td>
                                <td colspan="2" class="text-right">{{ $total }}</td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="text-end">
                        <a href="{{ route('user.order.create') }}" class="btn btn-dark"><b>
                                {{ __('Process to Checkout') }}</b></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <!--(for all pagination,asc-desc,search,shorting)-->
    <script src="{{ asset('public/admin/assets/extra-libs/multicheck/datatable-checkbox-init.js') }}"></script>
    <script src="{{ asset('public/admin/assets/extra-libs/multicheck/jquery.multicheck.js') }}"></script>
    <script src="{{ asset('public/admin/assets/extra-libs/DataTables/datatables.min.js') }}"></script>

    <script>
        // $("#zero_config").DataTable();
        function changeqty(index) {
            $('#qty_' + index).css('display', 'block');
            $('#display_qty_' + index).css('display', 'none');
        }

        function saveqty(index, qty){
            $('#qty_' + index).css('display', 'none');
            var product_id = $('#product_id_' + index).val();
            $('#display_qty_' + index).css('display', 'block');
            $.ajax({
                type: 'POST',
                url: '{{ route('user.cart.qtyupdate') }}',
                data: {'product_id': product_id,'qty': qty,'_token' : '{{ csrf_token() }}'},
                dataType: 'json',
                success: function(data) {
                    $('#display_qty_' + index).html(qty);
                },
                error: function(data) {
                    console.log(data);
                }
            });
        }
    </script>
@endpush
