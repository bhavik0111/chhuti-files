@extends('admin.layout.master')
@section('content')

<h1>welcome Admin</h1>

@endsection
