@extends('admin.layout.master')

@section('content')
    
    <div class="innerpage-common comm-PTB">

            <!-- (FOR MSG) -->
            @if (session()->has('msg'))
                <div class="alert alert-success">
                    {{ session()->get('msg') }}
                </div>
            @endif
            @if (session()->has('error_msg'))
                <div class="alert alert-danger">
                    {{ session()->get('error_msg') }}
                </div>
            @endif
            <!-- (END MSG) -->
            <div class="card mb-3">
            <div class="card-body">
                <div class="card-header row">
                    <h4 class="card-title mb-3"><b>All orders</b></h4>
                    <!-- <div class="text-end">
                        <a href="{{ route('user.home') }}" class="btn btn-dark"><b> {{ __('Back') }}</b></a>
                    </div> -->
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th><b>ID</b></th>
                                <th><b>Order Date</b></th>
                                <th><b>First Name</b></th>
                                <th><b>Last name</b></th>
                                <th><b>Phone</b></th>
                                <th><b>Total Amount</b></th>
                                <th><b>Status</b></th>
                                <th><b>Action</b></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($orders as $order)
                                <tr>
                                    <td>{{ $order->order_id }}</td>
                                    <td>{{ $order->order_date }}</td>
                                    <td>{{ $order->first_name }}</td>
                                    <td>{{ $order->last_name }}</td>
                                    <td>{{ $order->phone }}</td>
                                    <td>{{ $order->total }}</td>
                                    <!-- <td>{{ $order->order_status }}</td> -->
                                    
                                    <td> 
                                        @if ($order->order_status == 1)
                                            {{ 'complite' }}
                                        @endif
                                        @if ($order->order_status == 2)
                                            {{ 'progress' }}
                                        @endif
                                        @if ($order->order_status == 0)
                                            {{ 'cencel' }}
                                        @endif
                                    </td>
                                    <td>
                                        <a href="{{ route('admin.allorder.view', ['id' => $order->order_id]) }}"
                                                    class="btn btn-info"><b>{{ __('view') }}</b>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
</div>
    </div>
@endsection


