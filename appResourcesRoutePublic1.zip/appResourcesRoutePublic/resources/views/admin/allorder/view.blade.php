@extends('admin.layout.master')
                                               
@section('content')

    <div class="innerpage-banner">
         <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
               <h3>Order View</h3>
            </div>
         </div>
    </div>
    <div class="innerpage-common comm-PTB">
           
        <main class="form-signin">
            <div class="card">
                <form method="POST" action="{{ route('user.order.view', ['id' => $order->order_id]) }}" enctype="multipart/form-data">
                    @csrf
                    <div class="card-body">
                        <!-- <h4 class="card-title">{{ __('Order') }}</h4> -->

                      

                        <div class="form-group row">
                            <label for="first_name"
                                class="col-sm-3 text-end control-label col-form-label"><b>{{ __('First Name') }}</b></label>
                            <div class="col-sm-9">
                                    {{ old('first_name', $order->first_name) }}
                            </div>  
                        </div>

                        <div class="form-group row">
                            <label for="last_name"
                                class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Last Name') }}</b></label>
                            <div class="col-sm-9">
                                    {{ old('last_name', $order->last_name) }}
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="phone"
                                class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Phone') }}</b></label>

                            <div class="col-sm-9">
                                {{ old('phone',$order->phone) }}
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-sm-3 text-end control-label col-form-label">
                                <b>{{ __('Email') }}</b>
                            </label>

                            <div class="col-sm-9">
                                {{ old('email',$order->email) }}
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-sm-3 text-end control-label col-form-label">
                                <b>{{ __('Products') }}</b>
                            </label>

                            <div class="col-sm-9">
                                @foreach ($order->productview()->get() as $key => $product)
                                    <div class="row">
                                        <div class="col-sm-3">
                                            {{ $product->product->name }}
                                        </div>
                                        <div class="col-sm-3">
                                            {{ $product->qty }}
                                        </div>
                                        <div class="col-sm-3">
                                            {{ $product->price }}
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="shipping_address" class="col-sm-3 text-end control-label col-form-label">
                                <b>{{ __('Shipping Address') }}</b>
                            </label>

                            <div class="col-sm-9">
                                {{ old('shipping_address',$order->shipping_address) }}
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="order_date" class="col-sm-3 text-end control-label col-form-label">
                                <b>{{ __('Order Date') }}</b>
                            </label>

                            <div class="col-sm-9">
                                {{ old('order_date',$order->order_date) }}
                            </div>
                        </div>
                    
                        <div class="form-group row">
                            <label class="col-sm-3 text-end control-label col-form-label">
                                <b>{{ __('Order Status') }}</b>
                            </label>

                            <div class="col-md-9">
                                <div class="form-check">
                                    @if ($order->order_status == 2) {{ 'YOUR ORDER IN PROGRESS....' }} @endif
                                </div>

                                <div class="form-check">
                                    @if ($order->order_status == 1) {{ 'YOUR ORDER COMPLITE' }} @endif
                                </div>

                                <div class="form-check">
                                    @if ($order->order_status == 0) {{ 'YOUR ORDER CANCEL' }} @endif 
                                </div>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </main>
        
    </div>
@endsection
@push('scripts')
<script>

     $(document).ready(function() {
          $('.summernote').summernote();
        });



function addrow()
    {
        var html =
        '<div class="prod_feature">'+
            '<div class="form-group row">' +
                '<label for="title"  class="col-sm-3 text-end control-label col-form-label">{{ __('Title') }}' +
                '</label>' +

                '<div class="col-sm-8">'+
                    '<input type="text" name="title[]" class="form-control title"  id="title" required>' +
                '</div>' +
                '<div class="col-sm-1">'+
                    '<button type="button" class="btn btn-danger deleteRow">Delete</button>'+
                '</div>' +
            '</div>' +

            '<div class="form-group row">'+
                '<label for="add_description" class="col-sm-3 text-end control-label col-form-label">{{ __('Description') }}'+
                '</label>' +

                '<div class="col-sm-8">' +
                    '<textarea class="form-control summernote" name="add_description[]" id="add_description">{{ old('add_description') }}</textarea>' +
                '</div>' +
            '</div>'+
        '</div>';

        $('.features').append(html);

        $('.summernote').summernote();
    }

    $(document).on('click','.deleteRow',function (e) {
        e.preventDefault();
        $(this).closest('.prod_feature').remove();
    })

</script>
@endpush

