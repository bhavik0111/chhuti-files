<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
  <!-- All Rights Reserved by Matrix-admin. Designed and Developed by
  <a href="https://www.wrappixel.com">WrapPixel</a>. -->

  

</footer>
<!-- ============================================================== -->
<!-- End footer -->