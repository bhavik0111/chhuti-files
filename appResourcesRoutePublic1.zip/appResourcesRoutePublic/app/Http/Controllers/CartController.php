<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Support\Facades\Session;

class CartController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //    $carts = Cart::with(['product'])->where('user_id',auth()->user()->id)->get()->all();

        //using session
        $carts = Session::get('cart'); //session array returns
        $prod_ids = [];
        if($carts){
        foreach ($carts as $key => $value) {
            $prod_ids[] = $value['product_id'];
        }
        }
        // dd($prod_ids);
        $cart_products = Product::whereIn('id', $prod_ids)
            ->get()
            ->all();

        return view('user.cart.cart', compact('carts','cart_products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        // dd($id);
        $carts = Cart::where('user_id', auth()->user()->id)
            ->where('product_id', $id)
            ->get()
            ->all();
        if ($carts) {
            return redirect()
                ->back()
                ->with('msg', 'Product Already Exist in Cart');
        }
        // $cart = new Cart();
        // $cart->user_id= auth()->user()->id;
        // $cart->product_id= $id;
        // $cart->qty= 1;
        // $cart->price= 0;
        // $cart->save();
        $carts = Session::get('cart');
        $carts = array_merge($carts, [['product_id' => $id, 'qty' => 1]]);
        Session::put('cart', $carts);
        // dump(Session::get('cart'));
        // Session::forget('cart');
        // dd(Session::get('cart'));
        return redirect()
            ->route('user.home')
            ->with('msg', 'Product Added in Cart');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // $cart = Cart::where('user_id', auth()->user()->id)
        //     ->where('product_id', $request->product_id)
        //     ->get()
        //     ->first();
        // $cart->qty = $request->qty;
        // $cart->save();

        //using session
        $carts = Session::get('cart');
        foreach ($carts as &$val)
        {
            if ($val["product_id"] == $request->product_id) {
                $val["qty"] = $request->qty;
            }
        }
        Session::put('cart', $carts);
        return true;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
