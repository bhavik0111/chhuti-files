<?php

namespace App\Http\Controllers;
use App\Models\Blog;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    protected $dirPath = 'images/blog_images/';

    public function index(Request $request)    //<--(BLOG LISTING...)-->
    {
        $blog = Blog::get();
        return view('admin.blogs.index', compact('blog'));
    }

    public function create(Request $request)  //<--(BLOG FORM CREATE)-->  
    {
        return view('admin.blogs.create');
    }

    public function store(Request $request)   //<--(INSERT IN DB...)-->
    {
        $request->validate([
            'image' => ['required'],
            'title' => ['required'],
            'description' => ['required'],
            'status' => 'required'
        ]);

       
        $blog = new Blog();
        $blog->title = $request->title;
        $blog->description = $request->description;
        $blog->status = $request->status;

        if ($request->has('image')) {
            // folder name where you wan to upload
            $image = $request->file('image'); // name of your input field
            
            $image_name = rand() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path($this->dirPath), $image_name); // for store in folder

            $blog->image = $this->dirPath . $image_name; // for store in database
        }
        $blog->save();
        
        return redirect()->route('admin.blogs.index')->with('msg', 'Record Successfully Inserted');
    }

    public function edit($id)    //<--(BLOG EDIT FORM DISPLAY...)-->
    {
        
        $blog = Blog::where('id', $id)->first();
        // if(empty($blog))
        // {
        //     return redirect()->route('admin.blogs.index');
        // }
        return view('admin.blogs.edit', compact('blog'));
    }

    // function update(Request $req)
    // {
    //     //user UPDATE IN DB...
    //     $category = Category::where('id', $req->id)->first();
    //     // dd($req);
    //     $category->name = $req->name;
    //     // $category->price = $req->price;
    //     $category->description = $req->description;
    //     $category->status = $req->status;

    //     if ($req->has('cat_image')) {
    //         //=>this condition use if edit form and not upload
    //         //image then consider old image
    //         if (file_exists(public_path($category->image))) {
    //             @unlink(public_path($category->image));
    //         }
    //         $image = $req->file('cat_image'); // name of your input field

    //         $image_name = rand() . '.' . $image->getClientOriginalExtension();
    //         $image->move(public_path($this->dirPath), $image_name); // for store in folder

    //         $category->image = $this->dirPath . $image_name; // for store in database
    //     }

    //     $category->save();

    //     return redirect()
    //         ->route('admin.category.index')
    //         ->with('msg', 'Record Updated');
    // }



}
